// OneSupport v5.19 license configuration.
// After deploying the included license server, replace the URL below with its HTTPS URL.
const LICENSE_API_URL = 'http://localhost:8787';
const LICENSE_CHECK_INTERVAL_MS = 60 * 60 * 1000; // 1 hour
const LICENSE_GRACE_MS = 24 * 60 * 60 * 1000; // 24 hours
