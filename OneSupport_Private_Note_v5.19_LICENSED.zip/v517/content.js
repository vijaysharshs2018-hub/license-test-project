
(() => {
  if (window.__oneSupportPrivateNoteV5) return;
  window.__oneSupportPrivateNoteV5 = true;

  const state = {running:false, stop:false, timer:null};
  const OPEN_RENDER_WAIT = 3000;
  const NEXT_CHAT_WAIT = 3000;

  const sleep = ms => new Promise(r=>setTimeout(r,ms));
  const clean = s => (s||"").replace(/\s+/g," ").trim().toLowerCase();

  function visible(el){
    if(!el) return false;
    const r=el.getBoundingClientRect(), cs=getComputedStyle(el);
    return r.width>0 && r.height>0 && cs.display!=="none" && cs.visibility!=="hidden" && cs.opacity!=="0";
  }

  function text(el){ return clean(el?.innerText || el?.textContent || ""); }

  function fireClick(el){
    if(!el) return false;
    try { el.scrollIntoView({block:"center",inline:"center"}); } catch{}
    const r=el.getBoundingClientRect();
    const x=r.left+r.width/2, y=r.top+r.height/2;
    for(const type of ["pointerdown","mousedown","pointerup","mouseup","click"]){
      try { el.dispatchEvent(new MouseEvent(type,{bubbles:true,cancelable:true,view:window,clientX:x,clientY:y,button:0})); } catch{}
    }
    try { el.click(); } catch{}
    return true;
  }

  function clickableAncestor(el){
    let n=el;
    for(let i=0;i<7 && n;i++,n=n.parentElement){
      if(!visible(n)) continue;
      const role=n.getAttribute?.("role");
      const tag=(n.tagName||"").toLowerCase();
      const cs=getComputedStyle(n);
      if(["button","a"].includes(tag) || role==="button" || cs.cursor==="pointer") return n;
    }
    return el;
  }

  function allVisibleElements(){
    return [...document.querySelectorAll("*")].filter(visible);
  }

  function findIssueRows(){
    // The Chats table in the user's screenshots has a numeric Issue ID followed immediately
    // by the binocular control. We identify issue-id text first, then choose the nearest
    // small clickable control to its right, never the left expand arrow.
    const out=[];
    const seen=new Set();
    for(const el of allVisibleElements()){
      const t=(el.childElementCount===0 ? text(el) : "");
      if(!/^\d{6,12}$/.test(t)) continue;
      const r=el.getBoundingClientRect();
      if(r.width>130 || r.height>50) continue;
      const issue=t;
      if(seen.has(issue)) continue;
      let best=null, bestDist=Infinity;
      for(const c of allVisibleElements()){
        if(c===el) continue;
        const cr=c.getBoundingClientRect();
        if(cr.left <= r.right-2) continue;
        if(cr.left-r.right > 70) continue;
        if(cr.top > r.bottom+12 || cr.bottom < r.top-12) continue;
        const area=cr.width*cr.height;
        if(area<20 || area>1200) continue;
        const label=text(c);
        // Avoid selecting textual cells.
        const clickable = c.matches?.("button,a,[role=button]") ||
          getComputedStyle(c).cursor==="pointer" ||
          c.querySelector?.("svg,img");
        if(!clickable) continue;
        const d=cr.left-r.right;
        if(d<bestDist){best=c;bestDist=d;}
      }
      if(best){
        seen.add(issue);
        out.push({issue, issueEl:el, control:clickableAncestor(best), top:r.top});
      }
    }
    out.sort((a,b)=>a.top-b.top);
    return out;
  }

  function chatOpen(){
    // User's chat drawer has "Issue id #..." in its header.
    return allVisibleElements().some(e => /^issue id\s*#\d+/i.test(text(e)));
  }

  function findPrivateNoteTrigger(){
    // IMPORTANT: this is the REAL visible "Add private note" control in the
    // open chat, not anything in the extension popup and not the normal message box.
    const nodes=[...document.querySelectorAll('button,a,[role="button"],input[type="button"],input[type="submit"]')]
      .filter(visible);

    const exact=[];
    for(const el of nodes){
      const label=clean(
        el.innerText || el.textContent || el.getAttribute('aria-label') ||
        el.getAttribute('title') || el.value || ''
      );
      if(label==='add private note') exact.push(el);
    }

    // Prefer the control physically closest to the bottom of the currently
    // open chat drawer. This avoids stale/hidden controls from the page shell.
    exact.sort((a,b)=>{
      const ar=a.getBoundingClientRect(), br=b.getBoundingClientRect();
      return Math.abs(window.innerHeight-ar.bottom)-Math.abs(window.innerHeight-br.bottom);
    });

    if(exact[0]) return exact[0];

    // Fallback for custom elements whose text is not exposed on the button itself.
    const textNodes=[...document.querySelectorAll('*')].filter(visible).filter(el=>clean(el.textContent)==='add private note');
    textNodes.sort((a,b)=>{
      const ar=a.getBoundingClientRect(), br=b.getBoundingClientRect();
      return Math.abs(window.innerHeight-ar.bottom)-Math.abs(window.innerHeight-br.bottom);
    });
    return textNodes[0] ? clickableAncestor(textNodes[0]) : null;
  }

  function findPrivateDialog(){
    // Find the ACTUAL modal textarea first. The placeholder is unique to the
    // Add private note dialog and is safer than relying on React's DOM nesting.
    const editors=[...document.querySelectorAll('textarea,input,[contenteditable="true"]')]
      .filter(visible)
      .filter(e=>clean(e.getAttribute('placeholder')||'').includes('type private note here'));

    for(const editor of editors){
      let n=editor;
      for(let i=0;i<12 && n;i++,n=n.parentElement){
        if(!visible(n)) continue;
        const r=n.getBoundingClientRect();
        if(r.width<300 || r.height<150) continue;

        const add=[...n.querySelectorAll('button,[role="button"],a,input[type="button"],input[type="submit"]')]
          .filter(visible)
          .find(e=>clean(e.innerText||e.textContent||e.value||e.getAttribute('aria-label')||'')==='add note');
        if(add) return {container:n, editor, add};
      }
    }
    return null;
  }

  function findPrivateEditor(dialogInfo){
    if(!dialogInfo) return null;
    return dialogInfo.editor && visible(dialogInfo.editor) ? dialogInfo.editor : null;
  }

  function findAddNote(dialogInfo){
    if(!dialogInfo) return null;
    if(dialogInfo.add && visible(dialogInfo.add)) return dialogInfo.add;
    const dialog=dialogInfo.container;
    return [...dialog.querySelectorAll("button,[role=button],a")]
      .filter(visible).find(e=>text(e)==="add note") || null;
  }

  async function addPrivateNote(note, issue){
    const trigger=findPrivateNoteTrigger();
    if(!trigger) throw new Error(`${issue}: Add private note control not found`);
    // The chat MUST be fully rendered before we search for Add private note.
    // Do not search the DOM early: OneSupport renders the drawer asynchronously.
    fireClick(trigger);
    await sleep(OPEN_RENDER_WAIT);

    let info=null;
    for(let i=0;i<30;i++){
      info=findPrivateDialog();
      if(info) break;
      await sleep(150);
    }
    if(!info) throw new Error(`${issue}: Private Note modal not found`);

    const modal=info.container;
    const mr=modal.getBoundingClientRect();
    const editor=findPrivateEditor(info);
    if(!editor) throw new Error(`${issue}: exact Private Note textarea not found`);

    // Hard safety guard: the target must be physically inside the modal.
    const er=editor.getBoundingClientRect();
    if(er.left<mr.left-2 || er.right>mr.right+2 || er.top<mr.top-2 || er.bottom>mr.bottom+2)
      throw new Error(`${issue}: refusing to type outside the Private Note modal`);

    // Click the exact modal textarea. Then use the native textarea setter
    // so React receives the expected input event.
    fireClick(editor);
    await sleep(100);
    const setter=Object.getOwnPropertyDescriptor(HTMLTextAreaElement.prototype,"value")?.set;
    if(setter) setter.call(editor,note); else editor.value=note;
    editor.dispatchEvent(new InputEvent("input",{bubbles:true,inputType:"insertText",data:note}));
    editor.dispatchEvent(new Event("change",{bubbles:true}));
    await sleep(500);

    const current=(editor.value ?? "").trim();
    if(current!==note.trim())
      throw new Error(`${issue}: exact Private Note textarea was not populated`);

    const add=findAddNote(info);
    if(!add) throw new Error(`${issue}: Add Note not found inside Private Note modal`);

    const ar=add.getBoundingClientRect();
    if(ar.left<mr.left-2 || ar.right>mr.right+2 || ar.top<mr.top-2 || ar.bottom>mr.bottom+2)
      throw new Error(`${issue}: refusing to click Add Note outside modal`);

    // Ensure the button is enabled before clicking.
    for(let i=0;i<20 && (add.disabled || add.getAttribute("aria-disabled")==="true");i++)
      await sleep(150);

    if(add.disabled || add.getAttribute("aria-disabled")==="true")
      throw new Error(`${issue}: Add Note is disabled`);

    // Click Add Note exactly ONCE. Do not run another search/click cycle on the
    // same chat. The next chat is handled only after this function returns.
    fireClick(add);

    // Successful submission = the modal disappears AND the real Add private note
    // trigger becomes available again. This avoids treating an old private note
    // already visible in the conversation as proof of success.
    let closed=false;
    for(let i=0;i<50;i++){
      await sleep(150);
      if(!findPrivateDialog()){ closed=true; break; }
    }
    if(!closed) throw new Error(`${issue}: Add Note modal did not close after submission`);

    await sleep(500);
    if(!findPrivateNoteTrigger())
      throw new Error(`${issue}: Add Note closed but chat did not return to its normal state`);

    return true;
  }

  function closeChat(){
    const buttons=[...document.querySelectorAll("button,[role=button],a")].filter(visible);

    // OneSupport's chat drawer close control is the small X in the drawer
    // header. It may have no text, title, or aria-label, so do NOT rely on
    // its accessible name. First find the Issue ID header, then search for
    // the small right-most control in the same visible drawer/header area.
    const header=allVisibleElements().find(e=>/^issue id\s*#\d+/i.test(text(e)));
    if(header){
      const hr=header.getBoundingClientRect();
      let best=null, bestScore=-Infinity;
      for(const b of buttons){
        const r=b.getBoundingClientRect();
        const cx=r.left+r.width/2, cy=r.top+r.height/2;
        if(r.width<8 || r.height<8 || r.width>80 || r.height>80) continue;
        if(cy < hr.top-25 || cy > hr.bottom+45) continue;
        if(cx < hr.right-20) continue;
        const score=(cx-hr.right)*3 - Math.abs(cy-(hr.top+hr.height/2))*2;
        if(score>bestScore){bestScore=score;best=b;}
      }
      if(best){ fireClick(best); return true; }
    }

    // Fallback: explicitly look for close semantics.
    const x=buttons.find(b=>{
      const label=clean(b.innerText||b.textContent||b.getAttribute('aria-label')||b.getAttribute('title')||'');
      return label==='x' || label==='×' || label==='close' || label.includes('close chat') || label.includes('close drawer');
    });
    if(x){ fireClick(x); return true; }

    // Final fallback: small, right-most button in the top 130px of the
    // viewport. The extension popup is outside the page DOM, so this cannot
    // accidentally select the extension's STOP/RUN buttons.
    const cand=buttons.filter(b=>{
      const r=b.getBoundingClientRect();
      return r.top<130 && r.left>window.innerWidth-140 && r.width<80 && r.height<80;
    }).sort((a,b)=>b.getBoundingClientRect().left-a.getBoundingClientRect().left)[0];
    if(cand){ fireClick(cand); return true; }

    // If the UI exposes no DOM close button, Escape is the same user action
    // OneSupport uses to dismiss the drawer.
    try{
      document.dispatchEvent(new KeyboardEvent('keydown',{key:'Escape',code:'Escape',keyCode:27,which:27,bubbles:true,cancelable:true}));
      document.dispatchEvent(new KeyboardEvent('keyup',{key:'Escape',code:'Escape',keyCode:27,which:27,bubbles:true,cancelable:true}));
    }catch{}
    return false;
  }

  function findRowFresh(issue){
    // IMPORTANT: OneSupport re-renders the Chats table after a drawer opens/closes.
    // Never reuse an old DOM element from a previous row. Re-find the issue and
    // its binocular on every iteration.
    const rows=findIssueRows();
    return rows.find(r=>r.issue===String(issue)) || null;
  }

  function openIssueNumber(){
    const hit=allVisibleElements().find(e=>/^issue id\s*#\d+/i.test(text(e)));
    if(!hit) return null;
    const m=text(hit).match(/#(\d+)/);
    return m ? m[1] : null;
  }

  async function waitForChatClose(){
    for(let i=0;i<40;i++){
      if(!chatOpen()) return true;
      await sleep(150);
    }
    return false;
  }


  function pageFingerprint(){ return findIssueRows().map(r=>r.issue).join('|'); }
  function paginationCandidates(){ return [...document.querySelectorAll('button,a,[role="button"]')].filter(visible); }
  function paginationLabel(el){ return clean(el.getAttribute?.('aria-label') || el.getAttribute?.('title') || el.getAttribute?.('data-testid') || el.innerText || el.textContent || ''); }
  function findPaginationButton(kind){
    const matches=[];
    for(const el of paginationCandidates()){
      const label=paginationLabel(el), r=el.getBoundingClientRect();
      if(r.top < window.innerHeight*0.45) continue;
      if(kind==='next' && ((/(^|\b)(next|next page|go to next)(\b|$)/).test(label)) || ['>','›','»'].includes(label) || /chevron.?right|arrow.?right/.test(label)) matches.push(el);
      if(kind==='first' && ((/(^|\b)(first|first page|go to first)(\b|$)/).test(label)) || label==='1') matches.push(el);
    }
    matches.sort((a,b)=>{const ar=a.getBoundingClientRect(),br=b.getBoundingClientRect();return kind==='next'?br.left-ar.left:ar.left-br.left;});
    return matches[0]||null;
  }
  function paginationDisabled(el){ return !el || !!el.disabled || el.getAttribute('aria-disabled')==='true' || el.classList.contains('disabled') || !!el.closest?.('[aria-disabled="true"]'); }
  async function waitForPageChange(old){ for(let i=0;i<60;i++){await sleep(150);const now=pageFingerprint();if(now&&now!==old)return true;}return false; }
  async function goToNextPageOrRestart(){
    const before=pageFingerprint(), next=findPaginationButton('next');
    if(next && !paginationDisabled(next)){
      fireClick(next);
      if(await waitForPageChange(before)){ await sleep(NEXT_CHAT_WAIT); return {advanced:true,restarted:false}; }
      throw new Error('Next page control was clicked but the Chats page did not change.');
    }
    if(sessionStorage.getItem('__oneSupportAutoCycle')==='1'){
      sessionStorage.setItem('__oneSupportResumeAfterReload','1');
      console.log('[OneSupport Private Note] Last page completed — refreshing to restart from page 1.');
      location.reload();
      return {advanced:false,restarted:true};
    }
    return {advanced:false,restarted:false};
  }


  async function licenseInstallationId(){ return await new Promise(resolve=>chrome.storage.local.get(['installationId'],r=>{if(r.installationId)return resolve(r.installationId);const id=crypto.randomUUID();chrome.storage.local.set({installationId:id},()=>resolve(id));})); }
  async function ensureLicenseActive(){
    const data=await new Promise(resolve=>chrome.storage.local.get(['licenseKey','lastLicenseCheck'],resolve));
    if(!data.licenseKey) throw new Error('Active license required.');
    const deviceId=await licenseInstallationId();
    try{
      const res=await fetch(`${LICENSE_API_URL}/validate`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({licenseKey:data.licenseKey,deviceId})});
      const out=await res.json(); if(!res.ok||!out.active) throw new Error(out.message||'License inactive');
      await new Promise(resolve=>chrome.storage.local.set({lastLicenseCheck:Date.now(),licenseExpiresAt:out.expiresAt||null},resolve));
      return true;
    }catch(e){
      const age=Date.now()-(data.lastLicenseCheck||0);
      if(data.lastLicenseCheck&&age<LICENSE_GRACE_MS) return true;
      throw new Error('License check failed: '+e.message);
    }
  }

  async function runPass(){
    await ensureLicenseActive();
    state.stop=false;
    let sent=0, failed=0, pageCount=0;
    const processedAcrossPages=new Set();
    while(!state.stop){
      pageCount++;
      let initial=findIssueRows();
      if(!initial.length){ for(let i=0;i<30 && !initial.length;i++){await sleep(300);initial=findIssueRows();} }
      const issues=[], seen=new Set();
      for(const r of initial){const id=String(r.issue);if(!seen.has(id)){seen.add(id);issues.push(id);}}
      if(!issues.length) return `No Issue ID/binocular rows found on page ${pageCount}.`;
      for(const issue of issues){
        if(state.stop) break;
        if(processedAcrossPages.has(issue)) continue;
        try{
          let row=null; for(let retry=0;retry<20&&!row;retry++){row=findRowFresh(issue);if(!row)await sleep(300);}
          if(!row) throw new Error(`${issue}: row is no longer visible on the current Chats page`);
          fireClick(row.control);
          let opened=false; for(let j=0;j<50;j++){if(chatOpen()){opened=true;break;}await sleep(150);}
          if(!opened) throw new Error(`${issue}: chat drawer did not open`);
          await sleep(OPEN_RENDER_WAIT);
          await addPrivateNote(window.__oneSupportNote || 'MAINTAIN IR TIMELY AND ENSURE NO TIMEOUT HAPPENS',issue);
          sent++; processedAcrossPages.add(issue);
          await sleep(1200); closeChat();
          if(!await waitForChatClose()){
            try{document.dispatchEvent(new KeyboardEvent('keydown',{key:'Escape',code:'Escape',keyCode:27,which:27,bubbles:true,cancelable:true}));document.dispatchEvent(new KeyboardEvent('keyup',{key:'Escape',code:'Escape',keyCode:27,which:27,bubbles:true,cancelable:true}));}catch{}
            await sleep(1000);
          }
          if(!await waitForChatClose()) throw new Error(`${issue}: completed chat did not close after Add Note; note was already sent`);
          await sleep(NEXT_CHAT_WAIT);
        }catch(e){
          failed++; try{closeChat();}catch{} await waitForChatClose();
          throw new Error(`STOPPED at chat ${issue}. Notes sent: ${sent}. The extension did NOT continue because the Private Note was not confirmed. Reason: ${e.message}`);
        }
      }
      if(state.stop) break;
      const result=await goToNextPageOrRestart();
      if(result.restarted) return `Cycle complete: ${sent} private notes sent across ${pageCount} pages. Refreshing to page 1.`;
      if(!result.advanced) break;
    }
    return `Done: ${sent} private notes sent across ${pageCount} page(s), ${failed} failed.`;
  }

  chrome.runtime.onMessage.addListener((msg, sender, sendResponse)=>{
    if(msg.cmd==="STOP"){
      try{sessionStorage.removeItem("__oneSupportAutoCycle");sessionStorage.removeItem("__oneSupportResumeAfterReload");}catch{}
      state.stop=true;
      if(state.timer) clearInterval(state.timer);
      state.running=false;
      sendResponse({message:"Stopped."});
      return true;
    }
    window.__oneSupportNote=msg.note||"MAINTAIN IR TIMELY AND ENSURE NO TIMEOUT HAPPENS";
    if(msg.cmd==="RUN_ONCE"){
      if(state.running) { sendResponse({message:"Already running."}); return true; }
      state.running=true;
      runPass().then(message=>{
        state.running=false;
        sendResponse({message});
      }).catch(e=>{
        state.running=false;
        sendResponse({message:"ERROR: "+e.message});
      });
      return true;
    }
    if(msg.cmd==="START"){
      try{sessionStorage.setItem("__oneSupportAutoCycle","1");}catch{}
      if(state.running){sendResponse({message:"Already running."});return true;}
      // v5.18.1: automatic mode uses the exact same runPass() path as RUN TEST.
      // Schedule the next scan only AFTER the current full pass finishes.
      // This prevents overlapping/half-started scheduled cycles.
      state.stop=false;
      state.running=true;
      if(state.timer){ clearTimeout(state.timer); clearInterval(state.timer); state.timer=null; }

      const scheduleNext=()=>{
        if(state.stop){ state.running=false; state.timer=null; return; }
        state.timer=setTimeout(async()=>{
          state.timer=null;
          if(state.stop){state.running=false;return;}
          try{
            const message=await runPass();
            console.log("[OneSupport Private Note] scheduled scan:",message);
          }catch(e){
            console.error("[OneSupport Private Note] scheduled scan stopped:",e);
          }finally{
            if(!state.stop) scheduleNext();
            else state.running=false;
          }
        },300000);
      };

      // First automatic scan starts immediately and is identical to RUN TEST.
      (async()=>{
        try{
          const message=await runPass();
          console.log("[OneSupport Private Note] scheduled first scan:",message);
        }catch(e){
          console.error("[OneSupport Private Note] scheduled first scan stopped:",e);
        }finally{
          if(!state.stop) scheduleNext();
          else state.running=false;
        }
      })();

      sendResponse({message:"5-minute monitor started — full scan running now."});
      return true;
    }
  });
  try{
    if(sessionStorage.getItem('__oneSupportResumeAfterReload')==='1' && sessionStorage.getItem('__oneSupportAutoCycle')==='1'){
      sessionStorage.removeItem('__oneSupportResumeAfterReload');
      setTimeout(async()=>{
        if(state.running || state.stop) return;
        state.stop=false; state.running=true;
        try{ console.log('[OneSupport Private Note] resumed after page-1 refresh:',await runPass()); }
        catch(e){ console.error('[OneSupport Private Note] resumed scan stopped:',e); }
        finally{ state.running=false; }
      },4000);
    }
  }catch{}
})();
