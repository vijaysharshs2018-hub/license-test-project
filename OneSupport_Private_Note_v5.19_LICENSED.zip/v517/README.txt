OneSupport Private Note v5.19 Licensed Edition

This package includes remote license checks. Configure license-config.js with your deployed HTTPS license server URL, then update manifest.json host_permissions to match that domain. The extension checks the license before every pass and uses a 24-hour grace period for temporary connectivity issues.

Do not place the admin secret inside the extension. The included server package keeps admin operations server-side.
